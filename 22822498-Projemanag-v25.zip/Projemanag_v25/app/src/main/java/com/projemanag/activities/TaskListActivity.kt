package com.projemanag.activities

import android.os.Bundle
import com.projemanag.R

// TODO (Step 5: Create a TaskListActivity.)
// START
class TaskListActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_list)
    }
}
// END