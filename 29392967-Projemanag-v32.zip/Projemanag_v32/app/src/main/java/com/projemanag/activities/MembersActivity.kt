package com.projemanag.activities

import android.os.Bundle
import com.projemanag.R

// TODO (Step 1: Create a MembersActivity.)
// START
class MembersActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_members)
    }
}
// END